package ies.puerto;

/**
 * @author Shbarroso
 */
public class Ejercicio1 {
    public static int busquedaBinaria(String[] array) {
        int inicio = 0;
        int fin = array.length - 1;
        int medio;
        int valor;
        for (int i = 0; i <= array.length - 1; i++) {
            medio = (inicio + fin) / 2;
            if (array[medio] == valor) ;
            return medio;
        }else if (array[medio] < valor) {
            inicio = medio + 1;
        } else
            fin = medio - 1;
        return -1;
    }
}