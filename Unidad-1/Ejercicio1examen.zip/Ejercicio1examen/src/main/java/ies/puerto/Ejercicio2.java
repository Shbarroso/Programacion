package ies.puerto;

/**
 * @author Shbarroso
 */
public class Ejercicio2 {
    public static String calcularNota(String[] args) {
        int nota = 0;
        if (nota < 5) {
            return "suspendido";
        } else if (nota < 7) {
            return "aprobado";
        } else if (nota < 8) {
            return "bien";
        } else if (nota < 9) {
            return "notable";
        } else if(nota < 10) {
            return "sobresaliente";
        }
        return "matricula";
    }
    public static String calcularCaso(String[] args){
        int numero = 8;

        switch(numero) {
            case 0:
                return "suspendido";
            case 1:
                return "suspendido";
            case 2:
                return "suspendido";
            case 3:
                return "suspendido";
            case 4:
                return "suspendido";
            case 5:
                return "aprobado";
            case 6:
                return "bien";
            case 7:
                return "notable";
            case 8:
                return "notable";
            case 9:
                return "sobresaliente";
            case 10:
                return "matricula";
        }

    }
    return numero;

}
