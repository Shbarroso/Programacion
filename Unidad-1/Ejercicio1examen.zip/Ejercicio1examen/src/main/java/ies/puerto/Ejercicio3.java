package ies.puerto;


/**
 * Clase que implementa un ordenamiento de burbuja
 * @author Shbarroso
 */
public class Ejercicio3 {

    public static int ordenamientoBurbuja() {
        int[] numero = new int[5];
        numero[0] = 2;
        numero[1] = 4;
        numero[2] = 6;
        numero[3] = 8;
        numero[4] = 10;

        if (numero[0] > numero[1]) {
            int temp = numero[0];
            numero[0] = numero[1];
            numero[1] = temp;
        }
        if (numero [1] > numero [2]){
            int temp = numero [1];
            numero [1] = numero [2];
            numero [2] = temp;
        }
        if (numero[2] > numero[3]){
            int temp = numero[2];
            numero[2] = numero[3];
            numero[3] = temp;
        }
        if (numero[3] > numero[4]){
            int temp = numero[3];
            numero[3] = numero[4];
            numero[4] = temp;
        }
        if (numero[3] < numero[4]) {
            int temp = numero[3];
            numero[3] = numero[4];
            numero[4] =temp;
        }
        if (numero[2] < numero[3]) {
            int temp = numero[2];
            numero[2] = numero[3];
            numero[3] = temp;
        }
        if (numero[1] < numero[3])
    }
}