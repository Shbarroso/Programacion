package ies.puerto;


public class Ejercicio7 {
    /**
     * Ordena un array de enteros en orden ascendente.
     * @param args
     */
    public static void main(String[] args) {

    }
}