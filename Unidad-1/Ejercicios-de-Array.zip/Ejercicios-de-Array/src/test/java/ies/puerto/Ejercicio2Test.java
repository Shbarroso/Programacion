package ies.puerto;

import org.junit.Test;

public class Ejercicio2Test {

    Ejercicio2 ejercicio2 = new Ejercicio2();

    @Test
    public float calcularPromedioTest () {
        float resultado = ejercicio2.calcularPromedio()
        Assersions.assertEquals( )
    }
}
