package ies.puerto;

public class Ejercicio3Test {
    Ejercicio3 ejercicio3 = new Ejercicio3();

    @Test
    public void calcularMaximoTest() ´{
        int resultado = ejercicio3.calcularMaximo();
        Assertions.assertEqual();
    }
    @Test
    public void calcularMinimoTest() {
        int resultado = ejercicio3.calcularMinimo();
        Assertions.asserEqual();
    }


}
