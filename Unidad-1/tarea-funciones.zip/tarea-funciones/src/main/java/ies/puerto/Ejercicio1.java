package ies.puerto;

public class Ejercicio1 {

    /**
     * Función que realiza el calculo del área en triangulo
     * @param base para realizar el calculo
     * @param altura para realizar el calculo
     * @return areaTriangulo dado
     */
    public int areaTriangulo(int base, int altura) {
        int resultado = 0;
        resultado = (base*altura)/2;


        return resultado;
    }

}