package ies.puerto;

public class Ejercicio3 {
    /**
     * Función que realiza el cálculo del área en cuadrado y un rectángulo.
     * @param a lado del cuadrado
     * @return resultado
     */
    public int areaCuadrado(int a) {
        int resultado = 0;

        return resultado;
    }

    /**
     * Función que realiza el cálculo del área en cuadrado y un rectángulo.
     * @param a lado de un triangulo
     * @param b lado de un triangulo
     * @return resultado
     */
    public int areaRectangulo(int a, int b) {
        int resultado = 0;
        resultado = (a*b);


        return resultado;
    }
}