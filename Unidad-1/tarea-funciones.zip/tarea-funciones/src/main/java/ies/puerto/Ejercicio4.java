package ies.puerto;

public class Ejercicio4 {
    public int maxDosNumeros( int a, int b) {
        int resultado = 0;
        if (a < b)

    }


}