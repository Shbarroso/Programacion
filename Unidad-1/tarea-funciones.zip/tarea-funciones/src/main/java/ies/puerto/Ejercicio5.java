package ies.puerto;

public class Ejercicio5 {
    public boolean esPrimo(int numero) {
        if (numero <= 1) {
            return false;
        }

    }
}